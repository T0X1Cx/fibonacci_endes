package iessoterohernandezes2;

import iessoterohernandez.es.fibonacci;

public class fibonacciMain {

	public static void main(String[] args) {
		
		fibonacci fibonacci = new fibonacci(1000);
		
		  fibonacci.generarFibonacci();

	}

}
